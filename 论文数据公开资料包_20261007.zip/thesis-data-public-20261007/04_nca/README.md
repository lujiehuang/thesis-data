# NCA

`saved_workspace.RData` is an unchanged copy of the source `.RData`.
`nca_summary_saved_run.csv` contains unrounded values extracted during the audit from that saved run. They correspond to the current thesis table when rounded (effect sizes: 3 decimals; p-values: 4 decimals). This is not a new permutation run.
`06_history/nca_summary_original.csv` preserves the earlier CSV, whose p-values differ. No random seed or original software version has been inferred.
The three PNGs and bottleneck CSV are source copies; their filenames do not establish their numbering in the current thesis. All reported effect sizes are below .10.
