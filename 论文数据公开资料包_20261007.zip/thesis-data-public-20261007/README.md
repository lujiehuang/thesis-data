# Thesis data and analysis materials

Author: Lujie Huang. Source repository: https://github.com/lujiehuang/thesis-data

This release organizes questionnaire data and supporting SEM, fsQCA and NCA materials for the study of generative-AI-supported academic English writing among STEM postgraduates. The main analysis dataset contains 413 records and 31 substantive items across eight constructs.

Release date: 2026-10-07. Source commit: `6c67b3bdd040985d5eca12a17a571f33d2aaa634`.

## Start here / 使用顺序

1. Read `VERSION_NOTES.md` for the exact status of data and output versions.
2. Use `01_data/main/responses.csv` or `.sav` for the public item-level data, with the accompanying codebook. No rows or retained answers were changed.
3. Use `02_sem` for the SEM model/output and source tables, `03_fsqca` for construct scores, calibration versions and saved solutions, and `04_nca` for the saved R workspace and results.
4. `01_data/pilot` contains a separate historical pilot dataset; do not pool it with the main sample.
5. `06_history` preserves superseded design and result files for provenance. It is not the source of final manuscript claims.

## Constructs

| Code | Construct | Main items |
|---|---|---:|
| PDK | Perceived Domain Knowledge | 4 |
| WSE | Writing Self-Efficacy | 4 |
| RAE | Reflective AI Engagement | 5 |
| LAU | Language-oriented AI Use | 3 |
| ACD | AI-Supported Content Development | 3 |
| PWQ | Perceived Writing Quality | 4 |
| PCT | Perceived Critical Thinking | 4 |
| WUV | Writing Utility Value | 4 |

WUV refers to the value of academic English writing for future academic/professional goals; it is not AI usefulness or continuance intention. CAU is a historical label in the questionnaire export; the current item-variable mapping uses ACD. Productive use groups LAU and ACD conceptually and is not an additional measured latent variable.

## Software and data use

SEM files are supplied in SPSS/AMOS formats; fsQCA source files are supplied with the saved solution text; NCA uses R. Exact original versions/settings are reported only where documented in the supplied outputs. Repoint AMOS data paths to `01_data/main/responses.sav` when opening copied projects. The public data retain the model item names.

CSV files use UTF-8 with BOM. SAV files retain variable/value labels. Source `.bat` files are preserved for reference; this release has not executed them or included the bundled executables. Use the CSVs in your installed analysis software.

文件索引见 `FILE_INDEX.json`；版本差异和已做的整理见 `VERSION_NOTES.md`。本包是材料整理版，不表示待核对事项已解决，也不覆盖原仓库。仓库公开可访问与授予开放许可是两回事，本次未代作者添加许可。
