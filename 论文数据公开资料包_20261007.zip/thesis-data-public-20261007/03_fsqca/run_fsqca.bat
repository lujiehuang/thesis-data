@echo off
cd /d "%~dp0"
"%~dp0__init__.exe" "%~dp0table.xls"
pause
