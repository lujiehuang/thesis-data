# Main questionnaire data

Source: `毕业论文数据/TRY1.sav` at repository commit `6c67b3bdd040985d5eca12a17a571f33d2aaa634`.
Records: 413. All source rows and retained response values are preserved in source order.
This is a derived public copy, not a byte-identical copy of the source SAV.
Excluded fields: `index`, `totalseconds`, `totalvalue`, `Q21`, `Q22` (original export index, duration, aggregate export score, and open responses).
`public_row_id` is newly assigned. No cases were removed and no screening answers were changed.
Variable labels and available value labels are retained in the SAV and codebooks.
The main instrument has 31 substantive items with observed values 1–7. Read VERSION_NOTES.md for the screening-field reconciliation and calibration versions.
