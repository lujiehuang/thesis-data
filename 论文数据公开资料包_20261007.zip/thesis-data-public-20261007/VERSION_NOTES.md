# Version notes / 版本说明

This release separates current data, saved analysis outputs and historical materials. It does not change respondent answers or silently replace analysis inputs.

## Data

- Main public data: all 413 rows from TRY1.sav are retained. Original export sequence/duration/total and open responses are omitted from the public copy. Retained values were checked against the source SAV after re-export. The codebook is derived from source metadata.
- The saved main file has six rows with a negative answer on at least one screening question. The author reports that six excluded records were removed before providing the analysis data. Whether these refer to the same records, or to different versions/flags, remains to be reconciled. This release neither deletes these rows nor changes their answers.
- Source questionnaire instructions say five points while the response matrices show seven categories. The main item values are 1–7. The item labels in the public codebook preserve the actual SAV wording; no claim is made that the historical instructions have been retrospectively changed.
- Pilot data are historical and use their own item structure and labels.

## fsQCA

- QCA.csv construct means match the main item data in row order within numerical precision.
- Calibration source versions are retained separately. The comparison of 表副本.csv with 已校正-数据表.csv identifies 224 exact .5 adjustments to .5001 and 25 WSE changes from .57 to .50017. The latter require confirmation of the original processing steps. A text replacement can reproduce this pattern but does not establish how it was originally produced.
- No candidate repair has replaced the published inputs. No new minimization is claimed by this release. Exact original frequency, consistency, PRI and directional-expectation settings must be taken from the actual analysis record, not guessed from teaching examples.
- Historical configuration tables incorrectly label the outcome as Continuance Intention. The current outcome is Writing Utility Value. Their core/peripheral markings should not be adopted without comparison to matching solution outputs. These tables are preserved under 06_history, not presented as corrected final results.

## NCA

- The saved R workspace is retained unchanged. The new saved-run summary reports its extracted p-values, matching the current thesis table at the reported precision. The older summary is retained under 06_history.
- Differences between the earlier CSV and saved-run p-values are not all rounding differences. No unrecorded random seed or execution history is asserted.

## Packaging changes

- Removed from this release: temporary lock files, shortcuts, exact redundant copies, executable binaries, course access documents, unrelated research proposals, and unrelated administrative/writing drafts. Original repository files were not deleted.
- Omitted other unlabeled data exports from this focused release; this does not classify them as invalid or authorize their permanent deletion. Keep the original five ZIP files as the source archive.
- Historical v9 design is explicitly labeled as a draft (33 items and earlier questions), rather than the current 31-item instrument.
- The thesis itself is not altered by this release. Numerical concerns are recorded here for reconciliation.
