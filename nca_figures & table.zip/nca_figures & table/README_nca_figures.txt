Figure 1 shows that all CE-FDH effect sizes are below 0.10, indicating no strong necessary condition.
Figure 2 visualizes the CR-FDH bottleneck table; PCTALL1 has the highest threshold pattern as WUVALL1 increases.
Figure 3 follows the appendix style seen in recent NCA papers: scatter points plus a bottleneck line for each significant condition.



  - figure_1_nca_effect_sizes.png：最适合放正文
  - nca_summary.csv：整理成三线表，正文必放
  - nca_bottleneck_cr_fdh.csv：整理成三线表，正文可放
  - figure_2_bottleneck_heatmap.png：可放正文，也可不放
  - figure_3_scatter_bottleneck_panels.png：更适合附录
  - README_nca_figures.txt：论文里不用放，只是说明文件